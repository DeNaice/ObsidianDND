# 📅 Trainings-Schedule (5x pro Woche)

| Tag        | Training         | Fokus                    | Dauer     |
| ---------- | ---------------- | ------------------------ | --------- |
| Montag     | [[01_Push_A]]    | Brust, Schulter, Trizeps | 60–75 Min |
| Dienstag   | [[02_Pull_A]]    | Rücken, Bizeps           | 60 Min    |
| Mittwoch   | [[03_Legs]]      | Beine, Po, Core          | 60–75 Min |
| Donnerstag | ❌ Pause / Cardio | Regeneration             | –         |
| Freitag    | [[04_Push_B]]    | Brust, Schulter, Trizeps | 60 Min    |
| Samstag    | [[05_Pull_B]]    | Rücken, Bizeps, Core     | 60–75 Min |
| Sonntag    | ❌ Pause          | Erholung                 | –         |
