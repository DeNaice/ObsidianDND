# 📅 Trainings-Schedule (5x pro Woche)

| Tag        | Training         | Fokus                    |
| ---------- | ---------------- | ------------------------ |
| Montag     | [[01_Push_A]]    | Brust, Schulter, Trizeps |
| Dienstag   | [[02_Pull_A]]    | Rücken, Bizeps           |
| Mittwoch   | ❌ Pause / Cardio | Beine, Po, Core          |
| Donnerstag | [[03_Legs]]      | Regeneration             |
| Freitag    | [[04_Push_B]]    | Brust, Schulter, Trizeps |
| Samstag    | [[05_Pull_B]]    | Rücken, Bizeps, Core     |
| Sonntag    | ❌ Pause          | Erholung                 |

