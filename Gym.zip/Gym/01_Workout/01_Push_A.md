# 💥 Push A – Brust, Schulter, Trizeps

**Ziel:** Druckkraft aufbauen, Schulterstabilität verbessern  
**Dauer:** ca. 60–75 Minuten  

---

## Übungen

| Übung               | Gerät/Alternative         | Sätze x Wdh | Notizen             |
| ------------------- | ------------------------- | ----------- | ------------------- |
| [[Brustpresse]]     | später: Bankdrücken LH/KH | 4x8–12      | Fokus auf volle ROM |
| [[Schulterpresse]]  | KH-Schulterdrücken        | 3x8–12      | Rücken anlehnen     |
| [[Seitheben]]       | KH oder Maschine          | 3x12–15     | leichte Wdh, sauber |
| [[Trizepsdruecken]] | Seil oder Stange          | 3x10–12     | Ellbogen fixieren   |
| [[Plank]]           | statisch                  | 3x max.     | Spannung halten     |

---

## 🧠 Tipps
- Schultern warm machen (Rotatorenband)  
- Technik > Gewicht  
- Letzte Wiederholung sauber, nicht erzwingen  
