# 🧩 Enges Rudern
![[enges_rudern.jpg]]

## 🧠 Beschreibung
Kurze Erklärung, was trainiert wird und wozu die Übung dient.

## ⚙️ Setup & Ausführung
1. Vorbereitung / Geräte-Einstellung  
2. Startposition  
3. Bewegungsausführung  
4. Atmungshinweis  

## 🚫 Häufige Fehler
- Fehler 1  
- Fehler 2  
- Fehler 3  

## 📈 Progressionstipp
Wie du dich steigern kannst (z. B. Gewicht, Wiederholungen, Variation).

## 💬 Eigene Notizen
